var myFilterView = null;
sap.ui.controller("salesorders.SalesOrders", {

	/**
	 * Called when a controller is instantiated and its View controls (if available) are already created.
	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	 * @memberOf salesorders.SalesOrders
	 */

	onInit : function() {
		jQuery.sap.require("sap.ui.model.Filter");
		jQuery.sap.require("sap.ui.model.FilterOperator");

		jQuery.sap.require("sap.ui.core.Fragment");
		jQuery.sap.require("sap.ui.commons.TextView");
		this.getView().addEventDelegate({
			onBeforeShow : jQuery.proxy(function(oEvt) {
				this.onBeforeShow(oEvt);
			}, this)
			
		});
		
		/*var sServiceUrl = '\document.json';
		var post = $.ajax({
		    url : sServiceUrl,
		    type : "GET"
		});
		var oModel = new sap.ui.model.json.JSONModel();
		post.done(function(data) {
		oModel.setData(data);       
		})


		var dropdown = this.byId("idProductsTable");
		dropdown.setModel(oModel);
		var mainmodel;*/
		//var radio = this.byId("col3X");
		//radio.bindProperty("selected","col3X1");
	},

	//var selDesc = oSystemDetailsML.getProperty("Description", currentRowContext);
	getContextByIndex1 : function(evt) {
		var oTable = sap.ui.getCore().byId("table1");
		var model = oTable.getModel();
		var currentModel = model;
		var addLine = [ {} ];
		addLine[0].ItemCode = "";
		addLine[0].ItemName = "";
		addLine[0].Quantity = "1.0";
		addLine[0].ItemPrice = "0.00";
		addLine[0].Remarks = "";
		addLine[0].DiscPrcnt = "0.00";
		var currrentJSONob = currentModel.getProperty("/");
		for (i = 1; i <= currrentJSONob.length; i++) {
			addLine[i] = currrentJSONob[i - 1];
		}

		var sServiceUrl = '\Items.json';
		var post = $.ajax({
			url : sServiceUrl,
			type : "GET"
		});

		model = new sap.ui.model.json.JSONModel(addLine);
		oTable.setModel(model);

		var context = oTable.getContextByIndex("0");
		var path = context.getPath();
		var status = context.getModel().setProperty(path + "/Editable", true);

		post.done(function(data) {
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(data);
			var satus1000 = sap.ui.getCore().byId("table1").setModel(oModel,
					"TheFirstModel");
			/*for (var i = 0; i < data.length; i++) {
			var oItem = new sap.ui.core.ListItem("ID"+i.toString());
			oItem.setText(data[i].ItemName.toString());
			    dropdown.addItem(oItem);
			 var dropdownmodel = dropdown.getModel();
			 var statusDropDown = dopdownmodel.setProperty("/",data);
			}*/

		})

	},
	onChange : function(oEvent) {
		var path = oEvent.getSource().getBindingContext().sPath;
		var context = sap.ui.getCore().byId("table1").getContextByIndex(
				path.replace("/", ""));
		var status = context.getModel().setProperty(path + "/ItemCode",
				oEvent.oSource.mProperties.selectedKey);

	},
	setRating : function(oEvent) {
		var radioButton = oEvent.mParameters.id;
		var view = this.getView();
		var name = radioButton.includes("radio2");
		var isSelected = oEvent.mParameters.selected;
		if (name == true && isSelected == true) {
			var oDialog1 = new sap.ui.commons.Dialog();
			oDialog1.setTitle("Reason");
			
			var oDropdownBox1 = new sap.ui.commons.DropdownBox();
			oDropdownBox1.setTooltip();
			oDropdownBox1.setEditable(true);
			var oItem = new sap.ui.core.ListItem();
			oItem.setText("Wrong Price");
			oDropdownBox1.addItem(oItem);
			oItem = new sap.ui.core.ListItem();
			oItem.setText("Wrong Items");
			oDropdownBox1.addItem(oItem);
			oItem = new sap.ui.core.ListItem();
			oItem.setText("Wrong Video Format");
			oDropdownBox1.addItem(oItem);
			oItem = new sap.ui.core.ListItem();
			oItem.setText("Wrong SLA");
			oDropdownBox1.addItem(oItem);

			//var oText = new sap.ui.commons.TextField();
			//oText.setValue("");
			var data = oEvent.getSource().getBindingContext().getObject();
			var oModel = new sap.ui.model.json.JSONModel(data);
			//oText.setTooltip("Please specify the reason");
			var path = oEvent.getSource().getBindingContext().sPath;
			oDialog1.addContent(oDropdownBox1);
			oDialog1.addButton(new sap.ui.commons.Button({
				text : "OK",
				press : function() {
					var context = view.byId("idProductsTable");
					var status = context.getModel().setProperty(
							path + "/U_App_RejR", oDropdownBox1.getValue());
					oDialog1.close();
					/*			var oData = oModel.setProperty("/U_App_RejR",oText.getValue());
					 view.setModel(oData);*/
					var rejected = context.getModel().setProperty(
							path + "/U_Rejected", "true");
					var confirmed = context.getModel().setProperty(
							path + "/Confirmed", "false");
				}
			}));
			oDialog1.open();

		}else
			{
			var path = oEvent.getSource().getBindingContext().sPath;
			var context = view.byId("idProductsTable");
			var rejected = context.getModel().setProperty(
					path + "/U_Rejected", "false");
			var confirmed = context.getModel().setProperty(
					path + "/Confirmed", "true");}
	},

	onBeforeShow : function(evt) {
		this.byId("CompanyName").setText(evt.data);
		var Table = this.byId("idProductsTable");
		var oModel1 = new sap.ui.model.json.JSONModel("");
		Table.setModel(oModel1);
		/*var Table = this.byId("idProductsTable");

		var data = evt.data;
		$.ajax({
			url : sap.ui.getCore().getModel().getProperty("/oDataServiceUrl")
					+ "/API/GetOrders/",
			type : 'PUT',
			data : data,
			beforeSend : function(request) {
				sap.ui.core.BusyIndicator.show();
			},
			success : function(responseData, textStatus, jqXHR) {
				//alert(responseData.SessionId);
				sap.ui.core.BusyIndicator.hide();
				var oModel = new sap.ui.model.json.JSONModel(responseData);
				Table.setModel(oModel);
			},
			error : function(responseData, textStatus, errorThrown) {
				sap.ui.core.BusyIndicator.hide();

				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.error(JSON.stringify(responseData));
			}
		});*/
		// page1 is about to be shown; act accordingly - if required you can read event information from the evt object
	},
	editFormatter : function(sStatus) {
		if (sStatus == "true") {
			return false;
		} else {
			return true;
		}
	},
	editButton : function(sStatus) {
		if (sStatus == "true") {
			return false;
		} else {
			return true;
		}
	},
	confirmedFormatter : function(sStatus) {
		return sStatus === "true";
	},
	confirmedFormatter1 : function(sStatus) {
		if(sStatus === "true"){
			return "green";
		}
		if(sStatus1 === "true"){
			return "red";
		}
		
	},
	rejectedFormatter : function(sStatus) {
		return sStatus === "true";
	},
	onSave : function(oEvent) {
		var username = sap.ui.getCore().byId("loginPage").byId("UserName").getValue();
		var comp = sap.ui.getCore().byId("loginPage").byId("CompanyDb").getSelectedKey();
		var oView = this.getView();
		var oTable = oView.byId("idProductsTable");
		var model = oTable.getModel();
		var iIndex = oTable._aSelectedPaths;
		var sMsg;
		var lines = [];
		var listOfDoc = [];
		if (iIndex <= 0) {
			sMsg = "No item selected";
			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.error(sMsg);
		} else {
			iIndex.forEach(function(element) {
				var data = model.getProperty(element);
				var document = {};
				document.CardCode = data.CardCode;
				document.CardName = data.CardName;
				document.DocCur = data.DocCur;
				document.DocDate = data.DocDate;
				document.U_OrderReference = data.U_OrderReference;
				document.U_JobNumber = data.U_JobNumber;
				document.U_PONumber = data.U_PONumber;
				document.DocNum = data.DocNum;
				document.Confirmed = data.Confirmed;
				document.DocTotal = data.DocTotal; ;
				document.DocTotalFC = data.DocTotalFC; 
				document.U_App_RejB = username; 
				document.U_App_RejD = ""; 
				document.U_App_RejR = data.U_App_RejR; 
				document.U_Rejected = data.U_Rejected;
                document.Completed = data.Completed;
                document.Company = comp;
                document.DocumentLines = lines;
                listOfDoc.push(document);
			});
			var masterJSON = JSON.stringify(listOfDoc);
			var isA5 = oView.byId("isselected").getState();
			//var asd = sap.ui.getCore().getModel().getProperty("/oDataServiceUrl") + "/Items";
			$.ajax({
			       url: sap.ui.getCore().getModel().getProperty("/oDataServiceUrl") + "/API//Updatebatch/",
			       type: "PUT",
			       data: masterJSON,
			       contentType: "application/json",
			       beforeSend: function (request) {
						sap.ui.core.BusyIndicator.show();
					},
			    success: function(responseData, textStatus, jqXHR) {
			    	//alert(responseData.SessionId);
			    	$.ajax({
						url : sap.ui.getCore().getModel().getProperty("/oDataServiceUrl")
								+ "/API/GetOrders/",
						type : 'PUT',
						data : "{\"Database\":\x22"+  comp + "\x22"+",\"isA5\":" + "\x22" + isA5 + "\x22"+ "}",
						beforeSend : function(request) {
							sap.ui.core.BusyIndicator.show();
						},
						success : function(responseData, textStatus, jqXHR) {
							//alert(responseData.SessionId);
							var oModel = new sap.ui.model.json.JSONModel(responseData);
							oTable.setModel(oModel);
							var a = 0;
							oTable.getItems().forEach(function(element) {
								var adsad = oTable.getItems()[a].getCells()[11].getSelected();
										var adsad1 = oTable.getItems()[a].getCells()[12].getSelected();
								if(adsad === true)
								{
									$("#" + oTable.getItems()[a].getId()).css("background", "rgba(0, 0, 255,0.10)");
								
								}
								if(adsad1 === true)
								{
									$("#" + oTable.getItems()[a].getId()).css("background-color", "rgba(255,0,0,0.10)");
								}
								//Table.getItems()[a].addStyleClass("green");
								a = a + 1;
							});

								},
						error : function(responseData, textStatus, errorThrown) {
							sap.ui.core.BusyIndicator.hide();
							jQuery.sap.require("sap.m.MessageBox");
						}
								
					});	
			    	jQuery.sap.require("sap.m.MessageBox");
			    	sap.ui.core.BusyIndicator.hide();
					sap.m.MessageBox.success(responseData);
			    },
			    error: function (responseData, textStatus, errorThrown) {
						sap.ui.core.BusyIndicator.hide();
		        jQuery.sap.require("sap.m.MessageBox");
						sap.m.MessageBox.error(JSON.stringify(responseData));
			    }
			});
		}
	},
	handleDetailsPress : function(oEvent) {
		//var model = this.getView().byId("idProductsTable").getModel();
		//var DocNum = model.getProperty("DocNum", oEvent.getSource().getBindingContext());
		var data = oEvent.getSource().getBindingContext().getObject();
		var oModel = new sap.ui.model.json.JSONModel(data);
		indexOfJsonPro = oEvent.getSource().getBindingContext().sPath;
		var oData = oModel.getProperty("/Document_Lines");
		var oModel1 = new sap.ui.model.json.JSONModel(oData);

		var oData1 = oModel.getProperty("/Document_Lines");
		/*this.byId("CustomerCode").setText(oData1.CardCode);
		this.byId("CustomerName").setText(oData1.CardName);
		this.byId("OrderRef").setText(oData1.U_OrderReference);

		this.byId("DocCur").setText(oData1.DocCur);
		this.byId("DocNo").setText(oData1.DocNum);
		this.byId("DocDate").setText(oData1.DocDate);
		this.byId("PoNo").setText(oData1.U_PONumber);
		this.byId("JobNo").setText(oData1.U_JobNumber);
		 */
		$(sap.ui.getCore().byId("U_App_RejD")).hide();
		if (!this._oDialog) {
			this._oDialog = sap.ui.xmlfragment("salesorders.Dialog", this);
			var Dialog = this._oDialog;
		}

		//this._oDialog.setModel(oModel1);
		/*
				$.ajax({
					  url: sap.ui.getCore().getModel().getProperty("/oDataServiceUrl") + "/API/GetCurrentOrder/",
					  type: 'PUT',
					  data: "{\"DocNum\":\x22"+ DocNum + "\x22"+",\"Database\":" + "\x22" + "A5_AD_GB" + "\x22"+ "}",
					  success: function(responseData, textStatus, jqXHR) {
							//alert(responseData.SessionId);
						  
							var oModel = new sap.ui.model.json.JSONModel(responseData);  
							
							Dialog.setModel(oModel);
							//getId1.setModel(oModel);
							//getId2.setModel(oModel);
							Dialog.open();	
							},
						error: function (responseData, textStatus, errorThrown) {
							sap.ui.core.BusyIndicator.hide();
							
							jQuery.sap.require("sap.m.MessageBox");
							sap.m.MessageBox.error(JSON.stringify(responseData));
						}
					});
		 *///var getId1 = sap.ui.getCore().byId("table1");
		// Multi-select if required
		var bMultiSelect = !!oEvent.getSource().data("multi");
		//this._oDialog.setMultiSelect(bMultiSelect);

		// Remember selections if required
		this.getView().addDependent(this._oDialog);
		sap.ui.getCore().byId("table1").setModel(oModel1);
		sap.ui.getCore().byId("CustomerCode").setText(data.CardCode);
		sap.ui.getCore().byId("CustomerName").setText(data.CardName);
		sap.ui.getCore().byId("OrderRef").setText(data.U_OrderReference);
		sap.ui.getCore().byId("DocCur").setText(data.DocCur);
		sap.ui.getCore().byId("DocNo").setText(data.DocNum);
		sap.ui.getCore().byId("DocDate").setText(data.DocDate);
		sap.ui.getCore().byId("PoNo").setText(data.U_PONumber);
		sap.ui.getCore().byId("JobNo").setText(data.U_JobNumber);
		updateTime = data.U_App_RejD;
		if(data.Confirmed=="true"){
			var button = sap.ui.getCore().byId("UpdateButton").setEnabled(false);
			var button1 = sap.ui.getCore().byId("AddLineButton").setEnabled(false);
		}else{
			var button = sap.ui.getCore().byId("UpdateButton").setEnabled(true);
			var button1 = sap.ui.getCore().byId("AddLineButton").setEnabled(true);
		}
		var currrentJSONob = sap.ui.getCore().byId("table1").getModel().getProperty("/");
		//asdasdsadsa
		//var dropdown = sap.ui.getCore().byId("combobox").setProperty("Cardode",oData.ItemCode);
		for (i = 1; i <= currrentJSONob.length; i++) {
			var context = sap.ui.getCore().byId("table1").getContextByIndex(
					i - 1);
			var path = context.getPath();
			var status = context.getModel().setProperty(path + "/Editable",
					false);
		}

		//oFirstDialog.addContent(this._oDialog);
		// toggle compact style
		jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
		this._oDialog.open();
		var dialog = this._oDialog;
		document.addEventListener("click", function closeDialog(oEvent) {

			if (oEvent.target.id === "sap-ui-blocklayer-popup") {
				indexOfJsonPro="";
				dialog.close(); 
			}
		});
		loadTable = false;
	},
    onRefresh : function(oEvent){

		var oView = this.getView();
	var Table = this.byId("idProductsTable");
var isA5=oView.byId("isselected").getState();;
	var data = sap.ui.getCore().byId("loginPage").byId("CompanyDb").getSelectedKey();;
	$.ajax({
		url : sap.ui.getCore().getModel().getProperty("/oDataServiceUrl")
				+ "/API/GetOrders/",
		type : 'PUT',
		data : "{\"Database\":\x22"+  data + "\x22"+",\"isA5\":" + "\x22" + isA5 + "\x22"+ "}",
		beforeSend : function(request) {
			sap.ui.core.BusyIndicator.show();
		},
		success : function(responseData, textStatus, jqXHR) {
			//alert(responseData.SessionId);
			sap.ui.core.BusyIndicator.hide();
			var oModel = new sap.ui.model.json.JSONModel(responseData);
			Table.setModel(oModel);
			var a = 0;
			Table.getItems().forEach(function(element) {
				var adsad = Table.getItems()[a].getCells()[11].getSelected();
						var adsad1 = Table.getItems()[a].getCells()[12].getSelected();
				if(adsad === true)
				{
					$("#" + Table.getItems()[a].getId()).css("background", "rgba(0, 0, 255,0.10)");
				
				}
				if(adsad1 === true)
				{
					$("#" + Table.getItems()[a].getId()).css("background-color", "rgba(255,0,0,0.10)");
				}
				//Table.getItems()[a].addStyleClass("green");
				a = a + 1;
			});
		},
		error : function(responseData, textStatus, errorThrown) {
			sap.ui.core.BusyIndicator.hide();

			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.error(JSON.stringify(responseData));
		}
	});
   },
   onLogout : function(oEvent) {
	   app.to("loginPage");
	   var retval = location.reload();
   },
	onPress3 : function(OEvent) {
		var username = sap.ui.getCore().byId("loginPage").byId("UserName").getValue();
		var comp = sap.ui.getCore().byId("loginPage").byId("CompanyDb").getSelectedKey();
		var oView = this.getView();
		var oTable =sap.ui.getCore().byId("table1");
		var table = oView.byId("idProductsTable");
		var model = oTable.getModel();
		var iIndex = oTable.getBinding('rows').getContexts();
		var sMsg;
		var lines = [];
		var doc = {};
		doc.DocNum = sap.ui.getCore().byId("DocNo").getText();
		doc.Company = comp;
	     
		if (iIndex < 0) {
			sMsg = "no item selected";
		} else {
			var index= 0;
		
			iIndex.forEach(function(element) {
				var data = model.getProperty(element.sPath);
				var docLines = {};
				docLines.ItemCode = data.ItemCode;
				docLines.ItemName = data.ItemName;
				docLines.Quantity = data.Quantity||"";
				docLines.LineNum = data.LineNum||"";
				docLines.ItemPrice = data.ItemPrice||"0.00";
				docLines.DiscPrcnt = data.DiscPrcnt||"0.00";
				docLines.LineTotal = "";
				docLines.PriceAfterDis = "";
				lines.push(docLines);
                index = index+1;
			});
			doc.U_OrderReference = sap.ui.getCore().byId("OrderRef").getText();
			doc.U_App_RejD = updateTime;
			doc.U_App_RejB = username;
			doc.DocTotal = "";
			doc.DocTotalFC = "";
			doc.Document_Lines = lines;


			var innerTableModel= oTable.getModel();
			var oData = innerTableModel.getProperty("/");
			
			var context = table.getModel();
			var oDataOuterTable = context.oData;
			
			var selected = table._aSelectedPaths;
			
            var isA5 = oView.byId("isselected").getState();
			var masterJSON = JSON.stringify(doc);
			$.ajax({
			       url: sap.ui.getCore().getModel().getProperty("/oDataServiceUrl") + "/API/UpdateDocument/",
			       type: "PUT",
			       data: masterJSON,
			       contentType: "application/json",
			       beforeSend: function (request) {
						sap.ui.core.BusyIndicator.show();
					},
			    success: function(responseData, textStatus, jqXHR) {
			    	//alert(responseData.SessionId);
			    	/*$.ajax({
						url : sap.ui.getCore().getModel().getProperty("/oDataServiceUrl")
								+ "/API/GetOrders/",
						type : 'PUT',
						data : "{\"Database\":\x22"+  comp + "\x22"+",\"isA5\":" + "\x22" + isA5 + "\x22"+ "}",
						beforeSend : function(request) {
							sap.ui.core.BusyIndicator.show();
						},
						success : function(responseData, textStatus, jqXHR) {
							//alert(responseData.SessionId);
							var oModel = new sap.ui.model.json.JSONModel(responseData);
							table.setModel(oModel)
						},
						error : function(responseData, textStatus, errorThrown) {
							sap.ui.core.BusyIndicator.hide();

							jQuery.sap.require("sap.m.MessageBox");
							sap.m.MessageBox.error(JSON.stringify(responseData));
						}
					});*/
			    	jQuery.sap.require("sap.m.MessageBox");
					sap.ui.core.BusyIndicator.hide()
                    sap.m.MessageBox.success("Success");
					 var a = 0;

						oDataOuterTable[indexOfJsonPro.replace("/","")].Document_Lines = oData;
						responseData.forEach(function(element){
							var check = oDataOuterTable[indexOfJsonPro.replace("/","")].Document_Lines[a].LineNum||"";
							if((element.LineNum == oDataOuterTable[indexOfJsonPro.replace("/","")].Document_Lines[a].LineNum) || (check == "")){
							//oDataOuterTable[indexOfJsonPro.replace("/","")].Document_Lines = oData;
						oDataOuterTable[indexOfJsonPro.replace("/","")].DocTotal = element.DocTotal;
						oDataOuterTable[indexOfJsonPro.replace("/","")].U_App_RejD = element.U_App_RejD;
						oDataOuterTable[indexOfJsonPro.replace("/","")].DocTotalFC = element.DocTotalFC;
						oDataOuterTable[indexOfJsonPro.replace("/","")].Document_Lines[a].LineTotal=element.LineTotal;
						oDataOuterTable[indexOfJsonPro.replace("/","")].Document_Lines[a].PriceAfterDis = element.PriceAfterDis;
						oDataOuterTable[indexOfJsonPro.replace("/","")].Document_Lines[a].LineNum = element.LineNum;
						a = a + 1;
							}
						});
					var newModel = new sap.ui.model.json.JSONModel(oDataOuterTable);
					table.setModel(newModel);
					selected.forEach(function(element) {
						table.getItems()[element.replace("/","")].setSelected(true);
					});
					var  a = 0;
					var mParameters1 = {};
					mParameters1.query = oView.byId("FilterVal").getValue();
					var oEvent = {};
					oEvent.mParameters = mParameters1;
					

					table.getItems().forEach(function(element) {
								var adsad = table.getItems()[a].getCells()[11].getSelected();
										var adsad1 = table.getItems()[a].getCells()[12].getSelected();
								if(adsad === true)
								{
									$("#" + table.getItems()[a].getId()).css("background", "rgba(0, 0, 255,0.10)");
								
								}
								if(adsad1 === true)
								{
									$("#" + table.getItems()[a].getId()).css("background-color", "rgba(255,0,0,0.10)");
								}
								//Table.getItems()[a].addStyleClass("green");
								a = a + 1;
							});
					sap.ui.controller("salesorders.SalesOrders").filterGlobally(oEvent);
			    },
			    error: function (responseData, textStatus, errorThrown) {
						sap.ui.core.BusyIndicator.hide();
		        jQuery.sap.require("sap.m.MessageBox");
						sap.m.MessageBox.error(JSON.stringify(responseData));
			    }
			});
		}
		this._oDialog.close();
	},
	/**
	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	 * (NOT before the first rendering! onInit() is used for that one!).
	 * @memberOf salesorders.SalesOrders
	 */
	//	onBeforeRendering: function() {
	//
	//	},
	_filter : function() {
		var oFilter = null;
		var oView = null;
		if (this._oGlobalFilter && this._oPriceFilter) {
			oFilter = new sap.ui.model.Filter([ this._oGlobalFilter,
					this._oPriceFilter ], true);
		} else if (this._oGlobalFilter) {
			oFilter = this._oGlobalFilter;
		} else if (this._oPriceFilter) {
			oFilter = this._oPriceFilter;
		}
		myFilterView.byId("idProductsTable").getBinding("items").filter(
				oFilter, "Application");
	},

	filterGlobally : function(oEvent) {
		var sQuery = oEvent.mParameters.query;
		this._oGlobalFilter = null;

		if (sQuery) {
			this._oGlobalFilter = new sap.ui.model.Filter([
					new sap.ui.model.Filter("DocNum",
							sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("DocDate",
							sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("CardCode",
							sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("CardName",
							sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("U_OrderReference",
							sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("U_PONumber",
							sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("U_JobNumber",
							sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("DocTotal",
							sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("DocCur",
							sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("DocToalFC",
							sap.ui.model.FilterOperator.Contains, sQuery) ],
					false)
		}

		this._filter();
	},
	onSwitchAll : function(oEvent) {
		var company = sap.ui.getCore().byId("loginPage").byId("CompanyDb").getSelectedKey();
		
		var oView = this.getView();
		var oTable = oView.byId("idProductsTable");
		var state = oView.byId("isselected").getState();
		var isA5 = null;
		if(state==true){
			isA5 = "true"; }else{isA5 = "false";}
		$.ajax({
			url : sap.ui.getCore().getModel().getProperty("/oDataServiceUrl")
					+ "/API/GetOrders/",
			type : 'PUT',
			data : "{\"Database\":\x22"+  company + "\x22"+",\"isA5\":" + "\x22" + isA5 + "\x22"+ "}",
			beforeSend : function(request) {
				sap.ui.core.BusyIndicator.show();
			},
			success : function(responseData, textStatus, jqXHR) {
				//alert(responseData.SessionId);3
				sap.ui.core.BusyIndicator.hide();
				var oModel = new sap.ui.model.json.JSONModel(responseData);
				oTable.setModel(oModel);
				var  a = 0;
				oTable.getItems().forEach(function(element) {
							var adsad = oTable.getItems()[a].getCells()[11].getSelected();
									var adsad1 = oTable.getItems()[a].getCells()[12].getSelected();
							if(adsad === true)
							{
								$("#" + oTable.getItems()[a].getId()).css("background", "rgba(0, 0, 255,0.10)");
							
							}
							if(adsad1 === true)
							{
								$("#" + oTable.getItems()[a].getId()).css("background-color", "rgba(255,0,0,0.10)");
							}
							//Table.getItems()[a].addStyleClass("green");
							a = a + 1;
						});
			},
			error : function(responseData, textStatus, errorThrown) {
				sap.ui.core.BusyIndicator.hide();

				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.error(JSON.stringify(responseData));
			}
		});

	},
	
	onSwitchChange : function(oEvent) {
		var oView = this.getView();
		var oTable = oView.byId("idProductsTable");
		var state = oView.byId("selected").getState();
		if (state == true) {
			mainmodel = oTable.getModel();
			var iIndex = oTable._aSelectedPaths;
			var sMsg;
			var lines = [];
			var model = oTable.getModel();
			if (iIndex < 0) {
				sMsg = "no item selected";
			} else {
				iIndex.forEach(function(element) {
					var data = model.getProperty(element);
					lines.push(data);
				});
				model = new sap.ui.model.json.JSONModel(lines);
				oTable.setModel(model);
				isSelected = false;
			}
			;
		} else {
			oTable.setModel(mainmodel);
		}

	},
	/**
	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * @memberOf salesorders.SalesOrders
	 */
	onAfterRendering : function() {
		
		var Table = this.byId("idProductsTable");
		var isA5 = "true";
if(loadTable===true){
		var data = sap.ui.getCore().byId("loginPage").byId("CompanyDb").getSelectedKey();
		$.ajax({
			url : sap.ui.getCore().getModel().getProperty("/oDataServiceUrl")
					+ "/API/GetOrders/",
			type : 'PUT',
			data : "{\"Database\":\x22"+  data + "\x22"+",\"isA5\":" + "\x22" + isA5 + "\x22"+ "}",
			beforeSend : function(request) {
				sap.ui.core.BusyIndicator.show();
			},
			success : function(responseData, textStatus, jqXHR) {
				//alert(responseData.SessionId);
				sap.ui.core.BusyIndicator.hide();
				var oModel = new sap.ui.model.json.JSONModel(responseData);
				Table.setModel(oModel);
				/*var a = 0;
				Table.getItems().forEach(function(element) {
					$("#" + Table.getItems()[a].getId()).css("background-color", "#01FF70");
					//Table.getItems()[a].addStyleClass("green");
					a = a + 1;
				});*/
				/*Table.getItems().forEach(function(element) {
					element.$().addClass("red");
				});*/
			},
			error : function(responseData, textStatus, errorThrown) {
				sap.ui.core.BusyIndicator.hide();

				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.error(JSON.stringify(responseData));
			}
		});
	}
var oView = this.getView();
Table.onAfterRendering = function() {
	$("#" + oView.byId("Message1").getId()).css("background-color", "rgba(255,0,0,0.90)");
	$("#" + oView.byId("Message2").getId()).css("background-color", "rgba(255,0,0,0.90)");
	$("#" + oView.byId("Message1").getId()).css("font-size", "200%");
	$("#" + oView.byId("Message2").getId()).css("font-size", "200%");
	var tableColumns = Table.mAggregations.columns;
	var counter = 0;
	tableColumns.forEach(function(element) {
		$("#" + Table.mAggregations.columns[counter].mAggregations.header.sId).css("font-weight", "bold");
		counter = counter + 1;
	});
	var  a = 0;
	Table.getItems().forEach(function(element) {
				var adsad = Table.getItems()[a].getCells()[11].getSelected();
				var adsad1 = Table.getItems()[a].getCells()[12].getSelected();
	if(adsad === true)
	{
		$("#" + Table.getItems()[a].getId()).css("background", "rgba(0, 0, 255,0.10)");
	
	}
	if(adsad1 === true)
	{
		$("#" + Table.getItems()[a].getId()).css("background-color", "rgba(255,0,0,0.10)");
	}
	//Table.getItems()[a].addStyleClass("green");
	a = a + 1;
});

}
		//var table = this.byId("idProductsTable").setVisibleRowCountMode("1000");
		var iniPage = sap.ui.getCore().byId("idSalesOrders1");
		//asd.setTitle("How u doin"); //var oView = this.getView();
		//asd.byId("mainPage").setTitle("./AdstreamLogo.png");
		var page = iniPage.byId("Adstream");
		var oBar = new sap.m.Bar({
			contentLeft : [ new sap.ui.commons.Image({
				src : "./AdstreamLogo.png",
				height : "45px"
			}) ],
			contentMiddle : [ new sap.m.Label({
				text : "Open Sales Order",
				textAlign : "Left",
				design : "Bold"
			}) ],
			contentRight : []
		});
		page.setCustomHeader(oBar);
		app.setBackgroundImage("./AdstreamBig.png");
		app.setBackgroundColor("");
		app.setBackgroundOpacity(0.30);
		myFilterView = this.getView();
	}

/**
 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
 * @memberOf salesorders.SalesOrders
 */
//	onExit: function() {
//
//	}
});