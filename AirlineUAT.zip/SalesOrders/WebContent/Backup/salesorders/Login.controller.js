sap.ui.controller("salesorders.Login", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf b1ctimetrackapp.Login
*/
	onInit: function() {
		var model = new sap.ui.model.json.JSONModel();
		model.setData({
		    sessionInfo : "",
		    oDataServiceUrl : "http://lno1v-sapdapp01/SalesOrder1",
				userInfo : "",
				companyInfo : ""
		});
		

		sap.ui.getCore().setModel(model);
		 var button1 = this.byId("button2");
		 button1.setVisible(false);
		 var dropdown = this.byId("CompanyDb");
		 dropdown.setVisible(false);
		 var label = this.byId("com");
		 label.setVisible(false);
/*		 var dropdown = this.byId("CompanyDb");
		 dropdown.setVisible(false);*/
		/*var oSelect = this.byId("CompanyDb");
		oSelect.addItem(new sap.ui.core.Item("SBODemoIT", {
			text : "SBODemoIT",
			enabled : true,
			key : "SBODemoIT"
		}));*/
	},
//oDataServiceUrl : "http://localhost/SalesOrder",
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf b1ctimetrackapp.Login
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf b1ctimetrackapp.Login
*/
	onAfterRendering: function() {
		
		var iniPage =sap.ui.getCore().byId("loginPage");
		//asd.setTitle("How u doin"); //var oView = this.getView();
		//asd.byId("mainPage").setTitle("./AdstreamLogo.png");
var page = iniPage.byId("mainPage");
var oBar = new sap.m.Bar( {
          contentLeft : [ new sap.ui.commons.Image( {
          src : "./AdstreamLogo.png",
          height : "45px"
     }) ],
     contentMiddle : [ new sap.m.Label( {
          text : "Please Login",
          textAlign : "Left",
          design : "Bold"
     }) ],
     contentRight : []
});
page.setCustomHeader(oBar);
//		$.ajax({
//			url: sap.ui.getCore().getModel().getProperty("/oDataServiceUrl") + "/API/GetCompanies/",
//			type: "GET",
//			async: false,
//			beforeSend: function (request) {
//				sap.ui.core.BusyIndicator.show();
//				request.setRequestHeader("B1Session", sap.ui.getCore().getModel().getProperty("/sessionInfo"));
//			},
//			//headers: {"B1Session" : sap.ui.getCore().getModel().getProperty("/sessionInfo")},
//			contentType: "application/json; charset=utf-8",
//			crossDomain: true,
//			
//		});
	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf b1ctimetrackapp.Login
*/
//	onExit: function() {
//
//	}
/**
* Called when Login Button is pressed.
* @memberOf b1ctimetrackapp.Login
*/
	onPress: function (oEvent) {
		oView = this.getView();
		if(this.byId("UserName").getValue().length == 0){
			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.error("Specify an User Name");
		}
		else if(this.byId("Password").getValue().length == 0){
			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.error("Specify a Password");
		}
		else{
			// var dropdown = this.byId("CompanyDb");
			var dropdown = this.byId("CompanyDb");
			 var button = this.byId("button1");
			 var button1 = this.byId("button2");
			 var sUserName = this.byId("UserName").getValue();
				var sPassword = this.byId("Password").getValue();
				var label = this.byId("com");
			$.ajax({
				  url: sap.ui.getCore().getModel().getProperty("/oDataServiceUrl") + "/API/GetCompanies/",
				  type: 'PUT',
				  data: "{\"Email\":\x22"+  sUserName + "\x22"+",\"Password\":" + "\x22" + sPassword + "\x22"+ "}",
				  beforeSend: function (request) {
						sap.ui.core.BusyIndicator.show();
					},
				  success: function(responseData, textStatus, jqXHR) {
						//alert(responseData.SessionId);
					  sap.ui.core.BusyIndicator.hide();
						var oModel = new sap.ui.model.json.JSONModel();
						var data = $.parseJSON(responseData);
					    oModel.setData(data);   
					    
					    dropdown.setModel(oModel);
					    
					    dropdown.setVisible(true);
					    button.setVisible(false);
					    button1.setVisible(true);
					    label.setVisible(true);
						},
					error: function (responseData, textStatus, errorThrown) {
						sap.ui.getCore().getModel().setProperty("/oDataServiceUrl","http://10.44.112.76/SalesOrder1")
						$.ajax({
							  url: sap.ui.getCore().getModel().getProperty("/oDataServiceUrl") + "/API/GetCompanies/",
							  type: 'PUT',
							  data: "{\"Email\":\x22"+  sUserName + "\x22"+",\"Password\":" + "\x22" + sPassword + "\x22"+ "}",
							  beforeSend: function (request) {
									sap.ui.core.BusyIndicator.show();
								},
							  success: function(responseData, textStatus, jqXHR) {
									//alert(responseData.SessionId);
								  sap.ui.core.BusyIndicator.hide();
									var oModel = new sap.ui.model.json.JSONModel();
									var data = $.parseJSON(responseData);
								    oModel.setData(data);   
								    
								    dropdown.setModel(oModel);
								    
								    dropdown.setVisible(true);
								    button.setVisible(false);
								    button1.setVisible(true);
								    label.setVisible(true);
									},
								error: function (responseData, textStatus, errorThrown) {
									sap.ui.core.BusyIndicator.hide();
									sap.ui.getCore().getModel().setProperty("/oDataServiceUrl","http://lno1v-sapdapp01/SalesOrder1");
									jQuery.sap.require("sap.m.MessageBox");
									sap.m.MessageBox.error(JSON.stringify("Please enter correct credentials"));
								}
							});
						//jQuery.sap.require("sap.m.MessageBox");
						//sap.m.MessageBox.error(JSON.stringify("Please enter correct credentials"));
					}
				});

			

		}
							    
							    
	},
	onPress1: function (oEvent) {
		var dropdown = this.byId("CompanyDb");
		var data = dropdown.getSelectedKey();
   	 app.to("idSalesOrders1","slide",data,null);
	}
});
